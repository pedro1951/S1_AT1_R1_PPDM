import express from 'express';
import productsController from '../controllers/productsController.js'

const router = express.Router();

router.get("/", productsController.index)
router.post("/", productsController.store)
// router.put("/:id", productsController.)
router.put("/:id", productsController.update)
router.delete("/:id", productsController.destroy)

export default router;