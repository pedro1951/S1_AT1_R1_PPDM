import express from 'express';
import categoryController from '../controllers/categoryController.js';

const router = express.Router();

router.get("/", categoryController.index)
router.post("/", categoryController.store)
router.put("/:id", categoryController.update)
router.delete("/:id", categoryController.destroy)

export default router;