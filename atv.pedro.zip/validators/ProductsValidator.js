
export function validarCamposObrigatorios(products){
    const camposObrigatorios = ["nome", "preco", "descricao"]
    const camposFaltando = []

    camposObrigatorios.forEach((campo) => {
        if (products[campo] === undefined || products[campo] === null || products[campo].toString().trim() === "") {

            camposFaltando.push(campo)
        }
    })

    if(camposFaltando.length > 0) {
        throw new Error(`Campos obrigatorios nao preenchidos: ${camposFaltando.join(", ")}`)
    }
}

export function validarPreco(products){
    if(typeof products.preco !== "number" || products.preco <= 0){
throw new Error("preço deve ser um numero mair que zero")
    }
}

export function validarEstoque(products){
    if (products.estoque === null || products.estoque < 0){
        throw new Error("estoque nao pode ser negativo");
    }
}