import Produto from "../models/ProductModel.js";
import ProductRepository from "../repositories/ProductRepository.js";
import CategoryModel from "../repositories/CategoryRepository.js";
import {validarCamposObrigatorios, validarPreco, validarEstoque} from "../validators/product.validator.js";

class ProdutoService {
    async listar() {
        return await ProductRepository.getAllProduct()
    
    }

    async criarProduto(data) {
        validarCamposObrigatorios(data)
        
        validarPreco(data)
        validarEstoque(data)

        let categoria = await CategoryModel.getById(data.categoria_id);

        if(!categoria) {
            throw new Error("categoria nao existe")
        }

        if (categoria.status === 0) {
            throw new Error("nao e possivel cadastrar produto em categoria desativada")
        }

        if (data.destaque) {
            const totalDestaque = await ProductRepository.countDestaques();

            if (totalDestaque >= 5) {
                throw new Error('limite de produto em destaque foi atingido');
                
            }
        }
        const produto = new Produto(data);

        return await ProductRepository.createProduct(produto);
    }

    async atualizar(id, data) {
        if (!id) {
            throw new Error("id do produto e obrigatorio")
        }

        const produtoAtual = await ProductRepository.getById(id)

        if(!produtoAtual) {
            throw new Error("produto nao encontrado")
        }

        if(data.categoria_id) {
            const categoria = await CategoryModel.getById(data.categoria_id)

            if(!categoria || categoria.status === 0) {
                throw new Error('categoria invalida ou desativada')
            }
        }

        validarCamposObrigatorios(data)
        validarPreco(data)
        validarEstoque(data)

        if (data.destaque && !produtoAtual.destaque) {
            const totalDestaque = await ProductRepository.countDestaques();

            if (totalDestaque >= 5 ) {
                throw new Error("limite de produto em destaque atingido")
            }
        }

        const produto = new Produto(data);
     return await ProductRepository.updateProduct(id, produto);

    }
 async deletar(id) {
        if (!id) {
            throw new Error("id do produto é obrigatório")
        }

        return await ProductRepository.deleteProduct(id)
    }
}

export default new ProdutoService();