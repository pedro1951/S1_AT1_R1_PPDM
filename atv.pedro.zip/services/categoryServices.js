import Categoria from "../models/categoryModel.js";
import Produto from "../models/ProductsModel.js";
import categoryRepositories from "../repositories/categoryRepositories.js";
import productsRepository from "../repositories/productsRepository.js";

class categoriasServices{
async desativar(id){
        if(!id || isNaN(id)){
            throw new Error("ID de categoria e obrigatorio")
        }

        const categoria = Categoria.getById(id);

if (!categoria){
    throw new Error("categoria nao encontrado")
}
        

        await Categoria.updateStatus(id, 0);


        await Produto.desativarPorcategoria(id)

        return {message: "categoria e produto desativados com sucesso"}
    };
async delete(id){
const totalProdutos = await productsRepository.countBycategoria(id);

if (totalProdutos > 0){
    throw new Error("nao e possivel excluir categoria com produtos vinculados")
}

return await Categoria.delete(id);
}

async listarCategory(){
    return await categoryRepositories.getAllCategory();
}

    
async createCategory(data) {
const categoria = new Categoria(data);
return await categoryRepositories.createCategory(categoria);
      }
    

 async updateCategory(id, data){
const categoria = new Categoria(data);

return await categoryRepositories.updateCategory(id, categoria);
}

     async deletarCategory(id){
        if (!id){
            throw new Error("ID do produte e obrigatorio")
        }

        return await productsRepository.deleteProduct(id)
    }
}



export default new categoriasServices();