import express from 'express';
import cors from 'cors';
import produtosRoutes from './routes/ProductsRoutes.js';
import categoriaRoutes from './routes/categoryRoutes.js';
import errorHandler from './middlewares/errorHandler.js';


const app = express();

app.use(express.json());
app.use(cors());

http://Slocalhost:3000/produto
app.use("/produto", produtosRoutes);

http://localhost:3000/categoria
app.use("/categoria", categoriaRoutes);

app.use(errorHandler);
export default app;