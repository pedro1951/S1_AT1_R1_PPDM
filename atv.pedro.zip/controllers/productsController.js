import productsServices from "../services/productsServices.js";

class productsController {
  async index(req, res, next) {
    try {
      const products = await productsServices.listar(req.body);
      res.json(products);
    } catch (error) {
      next(error);
    }
  }

  async store(req, res, next) {
    try {
      await productsServices.criarProduto(req.body)
      res.status(201).json({ message: "Produto cadastrado com sucesso" });
    } catch (error) {
      next(error);
    }
  }

  async update(req, res, next) {
    try {
      const { id } = req.params;
    
      await productsServices.atualizar(id, req.body);
      res.status(201).json({ message: "Produto atualizado com sucesso" })
    } catch (error) {
      next(error);
    }
  }

  async destroy(req, res, next) {
    try {
      const { id } = req.params;

      await productsServices.deletar(id);
      res.status(201).json({ message: "Produto removido com sucesso" });
    } catch (error) {
      next(error);
    }
  }
}

export default new productsController();