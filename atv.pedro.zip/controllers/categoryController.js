import categoryServices from "../services/categoryServices.js";

class categoryController{

async index(req, res, next) {
    try{
    const categorys = await categoryServices.listarCategory();    
    res.json(categorys);
    } catch (error) {
        next(error);
    }
}

async store(req, res, next) {
    try {
        const categorys = req.body;

        await categoryServices.createCategory(categorys);
        res.status(201).json({ message: "category cadastrado com sucesso!"});
    }catch (error) {
        next(error);
    }
}

async update(req, res, next) {
    try{
        const { id } = req.params;
  const category =  req.body;

  await categoryServices.updateCategory(id, category);
  res.status(201).json({message: "category atualizado com sucesso"})
    }catch (error) {
        next(error);
    }
}

async destroy(req, res, next) {
      try{
         const {id} = req.params;
   
         await categoryServices.deletarCategory(id);
         res.status(200).json({message: "category removido com sucesso"})
      } catch (error) {
        next(error);
      }
   }
}
export default new categoryController()