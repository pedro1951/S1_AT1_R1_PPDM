import pool from "../database/conection.js"

class categoryRoutes{

async getById(id){
    const [rows] = await pool.query('SELECT * FROM categorias WHERE id = ?', [id]);
    return rows[0]
}

async updateStatus(id, status) {
    const [rows] = await pool.query('UPADETE category SET status = ? WHERE id = ?', [status, id]);
}

async getAllCategory() {
    const [rows] = await pool.query('SELECT * FROM categorias');
    return rows;
}

async createCategory(category) {
const { 
    nome, 
    descricao 
} = category;

const [result] = await pool.query (`INSERT INTO categorias (
    nome, descricao
    ) VALUES (?, ?)`, 
    [
        nome, 
        descricao
    ]
)

return result.insertId;
}

async updateCategory(id, category){

console.log(id, category)

      const {
         nome,
         descricao
      } = category;

      const [result] = await pool.query(`UPDATE categorias SET
         nome = ?,
         descricao = ?
         WHERE id = ?
         `, [
         nome,
         descricao,
         id
])

         return result.affectedRows;
      
   }

async deleteCategory(id) {
      const [result] = await pool.query(`DELETE FROM categorias WHERE id = ?`, [id])
   
      return result.affectedRows;
   }
}

   

export default new categoryRoutes()