import pool from "../database/conection.js"

class produtoRepository {
  async getAllproduct() {
    const [rows] = await pool.query('SELECT * FROM produtos');
    return rows;
  }

  async getByld(id) {
    const [rows] = await pool.query(`SELECT * FROM produtos WHERE id = ?`, [id]);
    return rows;
  }

  async desativarPorCategoria(categoriaId){
   await pool.query("UPDATE produtos SET status = 0 WHERE categoria_id = ?", [categoriaId])
  }

  async countByCategoria(categoriaId) {
    const [rows] = await pool.query('SELECT COUNT(*) as TOTAL FROM produtos WHERE categorias_id = ?', [categoriaId])

    return rows[0].total;
  }

  async countDestaques() {
    const [rows] = await pool.query('SELECT COUNT(*) as total FROM produtos WHERE categorias_id = ?')
    return rows[0].total;
  }

  async createProduct(produto){ 
  const [result] = await pool.query(`INSERT INTO produtos (
    nome, descricao, preco, quantidade_estoque, status, destaque, marca, modelo, garantia_meses, id_categoria
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      produto.nome,
      produto.descricao,
      produto.preco,
      produto.quantidade_estoque,
      produto.status,
      produto.destaque,
      produto.marca,
      produto.modelo,
      produtogarantia_meses,
      produto.id_categoria
    ]
  )

  return result.insertId;
}
async updateProduct(id, produto){
  const [result] = await pool.query(`UPDATE produtos SET
    nome = ?,
    descricao = ?,
    preco = ?,
    quantidade_estoque = ?,
    status = ?,
    destaque = ?,
    marca = ?,
    modelo = ?,
    garantia_meses = ?
    WHERE id = ?
    `, [
      produto.nome,
      produto.descricao,
      produto.preco,
      produto.quantidade_estoque,
      produto.status,
      produto.destaque,
      produto.marca,
      produto.modelo,
      produtogarantia_meses,
      id
  ])

  return result.affectedRows;
}

async deleteProduct(id){
  const [result] = await pool.query(`DELETE FROM produtos WHERE id = ?`, [id])
  return result.affectedRows
}


}

export default new produtoRepository()