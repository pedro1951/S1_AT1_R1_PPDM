import mysql from "mysql2/promise"
import env from "../configu/env.js"

const pool = mysql.createPool(env.db);

console.log("Pool Mysql criado.");

export default pool;